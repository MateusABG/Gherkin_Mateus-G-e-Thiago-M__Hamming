package com.bdd.jbehave;

public class HuffmanSteps { 
	
	@Given("")
	@When("")
	@When("")
	@Then("")
}
